import * as actionTypes from '../actions/actionTypes';
import { updateObject } from '../../shared/utility';

const initialState = {
    orders: [],
    loading: false,
    purchased: false
};

const bookingInit = ( state, action ) => {
    
    return updateObject( state, { purchased: false } );
};

const bookMovieStart = ( state, action ) => {
    return updateObject( state, { loading: true } );
};

const bookMovieSuccess = ( state, action ) => {
    
    const newOrder = updateObject( action.orderData, { id: action.orderId } );
    return updateObject( state, {
        loading: false,
        purchased: true,
        researvedseats:[],
        watchmovie:[],
        movieSelected:null,
        auditorium:null,
        totalPrice: 0,
        orders: state.orders.concat( newOrder )
    } );
};

const bookMovieFail = ( state, action ) => {
    return updateObject( state, { loading: false } );
};

const fetchOrdersStart = ( state, action ) => {
    return updateObject( state, { loading: true } );
};

const fetchOrdersSuccess = ( state, action ) => {
    return updateObject( state, {
        orders: action.orders,
        loading: false
    } );
};

const fetchOrdersFail = ( state, action ) => {
    return updateObject( state, { loading: false } );
};

const reducer = ( state = initialState, action ) => {
    
    switch ( action.type ) {
        case actionTypes.BOOKING_INIT: return bookingInit( state, action );
        case actionTypes.BOOK_MOVIE_START: return bookMovieStart( state, action );
        case actionTypes.BOOK_MOVIE_SUCCESS: return bookMovieSuccess( state, action )
        case actionTypes.BOOK_MOVIE_FAIL: return bookMovieFail( state, action );
        case actionTypes.FETCH_ORDERS_START: return fetchOrdersStart( state, action );
        case actionTypes.FETCH_ORDERS_SUCCESS: return fetchOrdersSuccess( state, action );
        case actionTypes.FETCH_ORDERS_FAIL: return fetchOrdersFail( state, action );
        default : return state;
    }
};

export default reducer;